// js/spaces.js - Arc-Inspired Multi-Profile Contextual Spaces Engine

import { state, persistJson, escapeHtml, DEFAULT_SHORTCUTS } from './state.js';
import { soundFx } from './audio.js';

export const SPACE_PRESETS = {
    space_work: {
        id: 'space_work',
        name: 'Trabajo & Dev',
        theme: 'cyber',
        accent: '#00f2fe',
        categoryIds: null,
        scratchpad: 'Notas de trabajo y proyectos activos...'
    },
    space_personal: {
        id: 'space_personal',
        name: 'Personal & Ocio',
        theme: 'nebula',
        accent: '#c084fc',
        categoryIds: ['cat_social', 'cat_shopping', 'cat_gaming', 'cat_google', 'cat_tools', 'cat_video'],
        scratchpad: 'Ideas personales, compras y lecturas pendientes...'
    },
    space_3d: {
        id: 'space_3d',
        name: '3D & Creación IA',
        theme: 'sunset',
        accent: '#fb923c',
        categoryIds: ['cat_3d', 'cat_ai', 'cat_art', 'cat_audio', 'cat_video', 'cat_google'],
        scratchpad: 'Prompts creativos, texturas y referencias de modelado...'
    }
};

export class SpacesEngine {
    constructor() {
        this.storageKey = 'hades_spaces_v1';
        this.data = this.loadSpaces();
    }

    defaultSpaces() {
        return Object.values(SPACE_PRESETS).map((preset) => ({
            id: preset.id,
            name: preset.name,
            theme: preset.theme,
            accent: preset.accent,
            categoryIds: preset.categoryIds ? [...preset.categoryIds] : null,
            scratchpad: preset.scratchpad
        }));
    }

    loadSpaces() {
        let parsed = null;
        try {
            const raw = localStorage.getItem(this.storageKey);
            if (raw) parsed = JSON.parse(raw);
        } catch (e) {}

        const defaults = this.defaultSpaces();
        if (!parsed || !Array.isArray(parsed.spaces) || !parsed.spaces.length) {
            return { activeSpaceId: 'space_work', spaces: defaults };
        }

        const byId = new Map(parsed.spaces.map((s) => [s.id, s]));
        const spaces = defaults.map((preset) => {
            const saved = byId.get(preset.id) || {};
            return {
                ...preset,
                name: saved.name || preset.name,
                theme: saved.theme || preset.theme,
                accent: preset.accent,
                categoryIds: preset.categoryIds ? [...preset.categoryIds] : null,
                scratchpad: saved.scratchpad !== undefined ? saved.scratchpad : preset.scratchpad,
                shortcuts: saved.shortcuts
            };
        });

        const activeSpaceId = spaces.some((s) => s.id === parsed.activeSpaceId)
            ? parsed.activeSpaceId
            : 'space_work';
        return { activeSpaceId, spaces };
    }

    saveSpaces() {
        persistJson(this.storageKey, this.data);
    }

    getActiveSpace() {
        return this.data.spaces.find((s) => s.id === this.data.activeSpaceId) || this.data.spaces[0];
    }

    allowsCategory(catId) {
        const space = this.getActiveSpace();
        if (!space || !Array.isArray(space.categoryIds) || space.categoryIds.length === 0) return true;
        return space.categoryIds.includes(catId);
    }

    hydrateCatalog() {
        const byId = new Map();
        (state.shortcuts || []).forEach((s) => {
            if (s && s.id) byId.set(s.id, s);
        });
        this.data.spaces.forEach((sp) => {
            (sp.shortcuts || []).forEach((s) => {
                if (s && s.id && !byId.has(s.id)) byId.set(s.id, s);
            });
        });
        const ensureCats = new Set(['cat_gaming', 'cat_ai', 'cat_google']);
        DEFAULT_SHORTCUTS.forEach((s) => {
            if (ensureCats.has(s.category) && !byId.has(s.id)) byId.set(s.id, { ...s });
        });
        const merged = [...byId.values()];
        state.shortcuts = merged;
        persistJson('custom_shortcuts_v2', merged);
    }

    applySpaceChrome() {
        const space = this.getActiveSpace();
        document.body.setAttribute('data-active-space', space ? space.id : 'space_work');
        if (space && space.accent) {
            document.body.style.setProperty('--space-accent', space.accent);
        }
    }

    switchSpace(spaceId) {
        if (spaceId === this.data.activeSpaceId) return;
        const target = this.data.spaces.find((s) => s.id === spaceId);
        if (!target) return;

        soundFx.play('chime');

        const current = this.getActiveSpace();
        if (current) {
            current.theme = state.theme;
            const padInput = document.getElementById('scratchpad-input');
            if (padInput) current.scratchpad = padInput.value;
        }

        this.data.activeSpaceId = spaceId;
        this.saveSpaces();
        this.applySpaceChrome();

        if (target.theme) state.setTheme(target.theme);

        const padInput = document.getElementById('scratchpad-input');
        if (padInput && target.scratchpad !== undefined) {
            padInput.value = target.scratchpad;
            localStorage.setItem('bento_scratchpad_notes', target.scratchpad);
            localStorage.setItem('hades_scratchpad_content', target.scratchpad);
        }

        this.renderHeaderSwitcher();
        state.emit('space:changed', spaceId);

        document.body.classList.add('space-transition-flash');
        setTimeout(() => document.body.classList.remove('space-transition-flash'), 300);
    }

    renderHeaderSwitcher(containerEl) {
        const container = containerEl || document.getElementById('spaces-switcher-bar');
        if (!container) return;

        const activeId = this.data.activeSpaceId;
        container.innerHTML = '';

        const cluster = document.createElement('div');
        cluster.className = 'spaces-cluster';

        const label = document.createElement('span');
        label.className = 'spaces-label';
        label.textContent = 'Perfiles';
        cluster.appendChild(label);

        const capsule = document.createElement('div');
        capsule.className = 'spaces-capsule';
        capsule.setAttribute('role', 'tablist');
        capsule.setAttribute('aria-label', 'Perfiles independientes');

        this.data.spaces.forEach((sp, idx) => {
            const btn = document.createElement('button');
            const isActive = sp.id === activeId;
            btn.type = 'button';
            btn.className = `space-pill ${isActive ? 'active' : ''}`;
            btn.setAttribute('data-space-id', sp.id);
            btn.setAttribute('role', 'tab');
            btn.setAttribute('aria-selected', String(isActive));
            btn.setAttribute('title', `${sp.name} · Alt+${idx + 1}`);
            btn.innerHTML = `<span class="space-glyph" aria-hidden="true"></span><span class="space-name">${escapeHtml(sp.name)}</span>`;

            btn.addEventListener('click', () => {
                soundFx.play('click');
                this.switchSpace(sp.id);
            });
            capsule.appendChild(btn);
        });

        cluster.appendChild(capsule);
        container.appendChild(cluster);
    }

    bindKeyboardShortcuts() {
        document.addEventListener('keydown', (e) => {
            if (e.altKey && !e.ctrlKey && !e.shiftKey) {
                const num = parseInt(e.key, 10);
                if (num >= 1 && num <= this.data.spaces.length) {
                    e.preventDefault();
                    const targetSpace = this.data.spaces[num - 1];
                    if (targetSpace) this.switchSpace(targetSpace.id);
                }
            }
        });
    }

    init() {
        this.hydrateCatalog();
        this.applySpaceChrome();
        this.renderHeaderSwitcher();
        this.bindKeyboardShortcuts();
        this.saveSpaces();
    }
}

export const spacesManager = new SpacesEngine();
